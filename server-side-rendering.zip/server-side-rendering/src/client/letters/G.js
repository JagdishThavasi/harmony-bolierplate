import React from 'react'

const G = ({prefix}) => (
  <span className="my-cool-class">
    {prefix}
    {' '}
    - G
  </span>
)

export default G
